﻿namespace pontoTuristico.Models
{
    public class cPontoTuristico
    {
        public int Id { get; set; }

        public string? Nome { get; set; }

        public string? Descricao { get; set; }

        public string? tipo_atracao { get; set; }

        public string? Estado { get; set; }

        public string? Cidade { get; set; }
    }
}
